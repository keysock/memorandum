from django.shortcuts import render,redirect

# Create your views here.
from learning_logs.models import Topic
from .forms import TopicForm


def index(requst):
    '''学习笔记的主页'''
    return render(requst,'learning_logs/index.html')

def topics(request):
    '''显示所有的主题'''
    topics=Topic.objects.order_by('date_added')
    context={'topics':topics}
    return render(request,'learning_logs/topics.html',context)

def topic(request,topic_id):
    '''显示所有的主题'''
    topic=Topic.objects.get(id=topic_id)
    entries=topic.entry_set.order_by('-date_added')
    context={'topic':topic,'entries':entries}
    return render(request,'learning_logs/topic.html',context)

def new_topic(request):
    if request.method != 'POST':
        form=TopicForm()
    else:
        form = TopicForm(data=request.POST)
        if form.is_valid():
            form.save()
            return redirect('learning_logs:topics')
    context={'form':form}
    return render(request,'learning_logs/new_topic.html',context)